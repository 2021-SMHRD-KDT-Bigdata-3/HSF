package DAODTO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


public class DAO {

	int cnt = 0;
	Connection conn = null;
	PreparedStatement psmt = null;
	ResultSet rs = null;
	DTO dto = null;

	// DB�� ����
	public void conn() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521:xe";
			String dbid = "hr";
			String dbpw = "hr";
			conn = DriverManager.getConnection(url, dbid, dbpw);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	// DB ��������
	public void close() {
		try {
			if (rs != null) {
				rs.close();
			}
			psmt.close();
			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

//-------------------------------------------------------------------------------------------------------------------

	// ȸ������
//	public int insert_member(String id, String pw, String nick, String email, String tel) {
//
//		try {
//			conn();
//
//			String sql = "insert into book_member values(?,?,?,?,?)";
//
//			psmt = conn.prepareStatement(sql);
//			psmt.setString(1, id);
//			psmt.setString(2, pw);
//			psmt.setString(3, nick);
//			psmt.setString(4, email);
//			psmt.setString(5, tel);
//
//			cnt = psmt.executeUpdate();
//
//		} catch (Exception e) {
//			System.out.println("ȸ������ ����");
//			e.printStackTrace();
//		} finally {
//			close();
//		}
//		return cnt;
//	}

//-----------------------------------------------------------------------------------------

	// ��õ���� Ŭ�� -> ����/ȿ��, �Ϸ���差, ���ۿ�, �Բ� �����ϸ� ���� ������ �˷������
	public DTO recom_comp(String component) {

		try {
			conn();

			String sql = "select effect, instruction from supplement where component = ?";

			psmt = conn.prepareStatement(sql);

			psmt.setString(1, component);

			rs = psmt.executeQuery();
			if (rs.next()) {
				String get_effect = rs.getString("effect");
				String get_instruction = rs.getString("instruction");

				dto = new DTO(get_instruction, get_effect);
			}
		} catch (Exception e) {
			System.out.println("��ȸ ����");
			e.printStackTrace();
		} finally {
			close();
		}
		return dto;
	}

//-----------------------------------------------------------------------------------

}
